var expiresInSeconds = context.getVariable("external_expires_in");
var expiresIn = Number(expiresInSeconds * 1000).toString();
context.setVariable("external_expires_in_ms", expiresIn);